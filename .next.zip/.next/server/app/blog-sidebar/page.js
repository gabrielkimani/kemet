(() => {
var exports = {};
exports.id = 249;
exports.ids = [249];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 3918:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-context.js");

/***/ }),

/***/ 5732:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/amp-mode.js");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 9274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 4486:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-blur-svg.js");

/***/ }),

/***/ 744:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config-context.js");

/***/ }),

/***/ 5843:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-config.js");

/***/ }),

/***/ 9552:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/image-loader");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 7342:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/no-ssr-error.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 2470:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/side-effect.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 618:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils/warn-once.js");

/***/ }),

/***/ 8598:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "metadata": () => (/* binding */ metadata),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_7__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2315);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2333);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2885);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9505);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(683);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3269);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5746);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8208);
/* harmony import */ var next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_7__);

    const tree = {
        children: [
        '',
        {
        children: [
        'blog-sidebar',
        {
        children: ['', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5278)), "C:\\Users\\dell\\Desktop\\next\\app\\blog-sidebar\\page.tsx"]}]
      },
        {
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 8514, 23)), "C:\\Users\\dell\\Desktop\\next\\app\\layout.tsx"],
'head': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 447)), "C:\\Users\\dell\\Desktop\\next\\app\\head.tsx"],
        }
      ]
      }.children;
    const metadata = [{
          type: 'layout',
          layer: 0,
          mod: () => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 8514, 23)),
          path: "C:\\Users\\dell\\Desktop\\next\\app\\layout.tsx",
        },{
          type: 'page',
          layer: 1,
          mod: () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5278)),
          path: "C:\\Users\\dell\\Desktop\\next\\app\\blog-sidebar\\page.tsx",
        },];
    const pages = ["C:\\Users\\dell\\Desktop\\next\\app\\blog-sidebar\\page.tsx"];

    
    
    
    

    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
  

/***/ }),

/***/ 2448:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 9797, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 2919, 23))

/***/ }),

/***/ 5278:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(8499);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(634);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(2890);
var link_default = /*#__PURE__*/__webpack_require__.n(next_link);
;// CONCATENATED MODULE: ./components/Blog/RelatedPost.tsx



const RelatedPost = ({ image , slug , title , date  })=>{
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
        className: "flex items-center lg:block xl:flex",
        children: [
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "mr-5 lg:mb-3 xl:mb-0",
                children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                    className: "relative h-[60px] w-[70px] overflow-hidden rounded-md sm:h-[75px] sm:w-[85px]",
                    children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                        src: image,
                        alt: title,
                        fill: true
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "w-full",
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx("h5", {
                        children: /*#__PURE__*/ jsx_runtime.jsx((link_default()), {
                            href: slug,
                            className: "mb-[6px] block text-base font-medium leading-snug text-black hover:text-primary dark:text-white dark:hover:text-primary",
                            children: title
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                        className: "text-xs font-medium text-body-color",
                        children: date
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const Blog_RelatedPost = (RelatedPost);

// EXTERNAL MODULE: ./components/Blog/SharePost.tsx
var SharePost = __webpack_require__(6874);
// EXTERNAL MODULE: ./components/Blog/TagButton.tsx
var TagButton = __webpack_require__(4110);
// EXTERNAL MODULE: ./components/Contact/NewsLatterBox.tsx
var NewsLatterBox = __webpack_require__(7029);
;// CONCATENATED MODULE: ./app/blog-sidebar/page.tsx






const BlogSidebarPage = ()=>{
    return /*#__PURE__*/ jsx_runtime.jsx(jsx_runtime.Fragment, {
        children: /*#__PURE__*/ jsx_runtime.jsx("section", {
            className: "overflow-hidden pt-[180px] pb-[120px]",
            children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "container",
                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "-mx-4 flex flex-wrap",
                    children: [
                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                            className: "w-full px-4 lg:w-8/12",
                            children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime.jsx("h2", {
                                        className: "mb-8 text-3xl font-bold leading-tight text-black dark:text-white sm:text-4xl sm:leading-tight",
                                        children: "10 amazing sites to download stock photos & digital assets for free"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                        className: "mb-10 flex flex-wrap items-center justify-between border-b border-body-color border-opacity-10 pb-4 dark:border-white dark:border-opacity-10",
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                className: "flex flex-wrap items-center",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                        className: "mr-10 mb-5 flex items-center",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                                className: "mr-4",
                                                                children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                                    className: "relative h-10 w-10 overflow-hidden rounded-full",
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                                                        src: "/images/blog/author-02.png",
                                                                        alt: "author",
                                                                        fill: true
                                                                    })
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                                className: "w-full",
                                                                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("h4", {
                                                                    className: "mb-1 text-base font-medium text-body-color",
                                                                    children: [
                                                                        "By",
                                                                        /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                                            children: " Musharof Chy"
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                        className: "mb-5 flex items-center",
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                                                className: "mr-5 flex items-center text-base font-medium text-body-color",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                                        className: "mr-3",
                                                                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("svg", {
                                                                            width: "15",
                                                                            height: "15",
                                                                            viewBox: "0 0 15 15",
                                                                            className: "fill-current",
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime.jsx("path", {
                                                                                    d: "M3.89531 8.67529H3.10666C2.96327 8.67529 2.86768 8.77089 2.86768 8.91428V9.67904C2.86768 9.82243 2.96327 9.91802 3.10666 9.91802H3.89531C4.03871 9.91802 4.1343 9.82243 4.1343 9.67904V8.91428C4.1343 8.77089 4.03871 8.67529 3.89531 8.67529Z"
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime.jsx("path", {
                                                                                    d: "M6.429 8.67529H5.64035C5.49696 8.67529 5.40137 8.77089 5.40137 8.91428V9.67904C5.40137 9.82243 5.49696 9.91802 5.64035 9.91802H6.429C6.57239 9.91802 6.66799 9.82243 6.66799 9.67904V8.91428C6.66799 8.77089 6.5485 8.67529 6.429 8.67529Z"
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime.jsx("path", {
                                                                                    d: "M8.93828 8.67529H8.14963C8.00624 8.67529 7.91064 8.77089 7.91064 8.91428V9.67904C7.91064 9.82243 8.00624 9.91802 8.14963 9.91802H8.93828C9.08167 9.91802 9.17727 9.82243 9.17727 9.67904V8.91428C9.17727 8.77089 9.08167 8.67529 8.93828 8.67529Z"
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime.jsx("path", {
                                                                                    d: "M11.4715 8.67529H10.6828C10.5394 8.67529 10.4438 8.77089 10.4438 8.91428V9.67904C10.4438 9.82243 10.5394 9.91802 10.6828 9.91802H11.4715C11.6149 9.91802 11.7105 9.82243 11.7105 9.67904V8.91428C11.7105 8.77089 11.591 8.67529 11.4715 8.67529Z"
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime.jsx("path", {
                                                                                    d: "M3.89531 11.1606H3.10666C2.96327 11.1606 2.86768 11.2562 2.86768 11.3996V12.1644C2.86768 12.3078 2.96327 12.4034 3.10666 12.4034H3.89531C4.03871 12.4034 4.1343 12.3078 4.1343 12.1644V11.3996C4.1343 11.2562 4.03871 11.1606 3.89531 11.1606Z"
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime.jsx("path", {
                                                                                    d: "M6.429 11.1606H5.64035C5.49696 11.1606 5.40137 11.2562 5.40137 11.3996V12.1644C5.40137 12.3078 5.49696 12.4034 5.64035 12.4034H6.429C6.57239 12.4034 6.66799 12.3078 6.66799 12.1644V11.3996C6.66799 11.2562 6.5485 11.1606 6.429 11.1606Z"
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime.jsx("path", {
                                                                                    d: "M8.93828 11.1606H8.14963C8.00624 11.1606 7.91064 11.2562 7.91064 11.3996V12.1644C7.91064 12.3078 8.00624 12.4034 8.14963 12.4034H8.93828C9.08167 12.4034 9.17727 12.3078 9.17727 12.1644V11.3996C9.17727 11.2562 9.08167 11.1606 8.93828 11.1606Z"
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime.jsx("path", {
                                                                                    d: "M11.4715 11.1606H10.6828C10.5394 11.1606 10.4438 11.2562 10.4438 11.3996V12.1644C10.4438 12.3078 10.5394 12.4034 10.6828 12.4034H11.4715C11.6149 12.4034 11.7105 12.3078 11.7105 12.1644V11.3996C11.7105 11.2562 11.591 11.1606 11.4715 11.1606Z"
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime.jsx("path", {
                                                                                    d: "M13.2637 3.3697H7.64754V2.58105C8.19721 2.43765 8.62738 1.91189 8.62738 1.31442C8.62738 0.597464 8.02992 0 7.28906 0C6.54821 0 5.95074 0.597464 5.95074 1.31442C5.95074 1.91189 6.35702 2.41376 6.93058 2.58105V3.3697H1.31442C0.597464 3.3697 0 3.96716 0 4.68412V13.2637C0 13.9807 0.597464 14.5781 1.31442 14.5781H13.2637C13.9807 14.5781 14.5781 13.9807 14.5781 13.2637V4.68412C14.5781 3.96716 13.9807 3.3697 13.2637 3.3697ZM6.6677 1.31442C6.6677 0.979841 6.93058 0.716957 7.28906 0.716957C7.62364 0.716957 7.91042 0.979841 7.91042 1.31442C7.91042 1.649 7.64754 1.91189 7.28906 1.91189C6.95448 1.91189 6.6677 1.6251 6.6677 1.31442ZM1.31442 4.08665H13.2637C13.5983 4.08665 13.8612 4.34954 13.8612 4.68412V6.45261H0.716957V4.68412C0.716957 4.34954 0.979841 4.08665 1.31442 4.08665ZM13.2637 13.8612H1.31442C0.979841 13.8612 0.716957 13.5983 0.716957 13.2637V7.16957H13.8612V13.2637C13.8612 13.5983 13.5983 13.8612 13.2637 13.8612Z"
                                                                                })
                                                                            ]
                                                                        })
                                                                    }),
                                                                    "12 Jan 2024"
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                                                className: "mr-5 flex items-center text-base font-medium text-body-color",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                                        className: "mr-3",
                                                                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("svg", {
                                                                            width: "18",
                                                                            height: "13",
                                                                            viewBox: "0 0 18 13",
                                                                            className: "fill-current",
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime.jsx("path", {
                                                                                    d: "M15.6375 0H1.6875C0.759375 0 0 0.759375 0 1.6875V10.6875C0 11.3062 0.309375 11.8406 0.84375 12.15C1.09687 12.2906 1.40625 12.375 1.6875 12.375C1.96875 12.375 2.25 12.2906 2.53125 12.15L5.00625 10.7156C5.11875 10.6594 5.23125 10.6312 5.34375 10.6312H15.6094C16.5375 10.6312 17.2969 9.87187 17.2969 8.94375V1.6875C17.325 0.759375 16.5656 0 15.6375 0ZM16.3406 8.94375C16.3406 9.3375 16.0312 9.64687 15.6375 9.64687H5.37187C5.09062 9.64687 4.78125 9.73125 4.52812 9.87187L2.05313 11.3063C1.82812 11.4187 1.575 11.4187 1.35 11.3063C1.125 11.1938 1.0125 10.9688 1.0125 10.7156V1.6875C1.0125 1.29375 1.32188 0.984375 1.71563 0.984375H15.6656C16.0594 0.984375 16.3687 1.29375 16.3687 1.6875V8.94375H16.3406Z"
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime.jsx("path", {
                                                                                    d: "M12.2342 3.375H4.69668C4.41543 3.375 4.19043 3.6 4.19043 3.88125C4.19043 4.1625 4.41543 4.3875 4.69668 4.3875H12.2623C12.5435 4.3875 12.7685 4.1625 12.7685 3.88125C12.7685 3.6 12.5154 3.375 12.2342 3.375Z"
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime.jsx("path", {
                                                                                    d: "M11.0529 6.55322H4.69668C4.41543 6.55322 4.19043 6.77822 4.19043 7.05947C4.19043 7.34072 4.41543 7.56572 4.69668 7.56572H11.0811C11.3623 7.56572 11.5873 7.34072 11.5873 7.05947C11.5873 6.77822 11.3342 6.55322 11.0529 6.55322Z"
                                                                                })
                                                                            ]
                                                                        })
                                                                    }),
                                                                    "50"
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                                                className: "flex items-center text-base font-medium text-body-color",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                                        className: "mr-3",
                                                                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("svg", {
                                                                            width: "20",
                                                                            height: "12",
                                                                            viewBox: "0 0 20 12",
                                                                            className: "fill-current",
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime.jsx("path", {
                                                                                    d: "M10.2559 3.8125C9.03711 3.8125 8.06836 4.8125 8.06836 6C8.06836 7.1875 9.06836 8.1875 10.2559 8.1875C11.4434 8.1875 12.4434 7.1875 12.4434 6C12.4434 4.8125 11.4746 3.8125 10.2559 3.8125ZM10.2559 7.09375C9.66211 7.09375 9.16211 6.59375 9.16211 6C9.16211 5.40625 9.66211 4.90625 10.2559 4.90625C10.8496 4.90625 11.3496 5.40625 11.3496 6C11.3496 6.59375 10.8496 7.09375 10.2559 7.09375Z"
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime.jsx("path", {
                                                                                    d: "M19.7559 5.625C17.6934 2.375 14.1309 0.4375 10.2559 0.4375C6.38086 0.4375 2.81836 2.375 0.755859 5.625C0.630859 5.84375 0.630859 6.125 0.755859 6.34375C2.81836 9.59375 6.38086 11.5312 10.2559 11.5312C14.1309 11.5312 17.6934 9.59375 19.7559 6.34375C19.9121 6.125 19.9121 5.84375 19.7559 5.625ZM10.2559 10.4375C6.84961 10.4375 3.69336 8.78125 1.81836 5.96875C3.69336 3.1875 6.84961 1.53125 10.2559 1.53125C13.6621 1.53125 16.8184 3.1875 18.6934 5.96875C16.8184 8.78125 13.6621 10.4375 10.2559 10.4375Z"
                                                                                })
                                                                            ]
                                                                        })
                                                                    }),
                                                                    "35"
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                className: "mb-5",
                                                children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                    href: "#0",
                                                    className: "inline-flex items-center justify-center rounded-full bg-primary py-2 px-4 text-sm font-semibold text-white",
                                                    children: "Design"
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                className: "mb-10 text-base font-medium leading-relaxed text-body-color sm:text-lg sm:leading-relaxed lg:text-base lg:leading-relaxed xl:text-lg xl:leading-relaxed",
                                                children: "Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat."
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                className: "mb-10 w-full overflow-hidden rounded",
                                                children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                    className: "relative aspect-[97/60] w-full sm:aspect-[97/44]",
                                                    children: /*#__PURE__*/ jsx_runtime.jsx((image_default()), {
                                                        src: "/images/blog/blog-details-01.jpg",
                                                        alt: "image",
                                                        fill: true,
                                                        className: "h-full w-full object-cover object-center"
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                                className: "mb-8 text-base font-medium leading-relaxed text-body-color sm:text-lg sm:leading-relaxed lg:text-base lg:leading-relaxed xl:text-lg xl:leading-relaxed",
                                                children: [
                                                    "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Quis enim lobortis scelerisque fermentum. Neque sodales ut etiam sit amet. Ligula ullamcorper",
                                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("strong", {
                                                        className: "text-primary dark:text-white",
                                                        children: [
                                                            " ",
                                                            "malesuada",
                                                            " "
                                                        ]
                                                    }),
                                                    "proin libero nunc consequat interdum varius. Quam pellentesque nec nam aliquam sem et tortor consequat. Pellentesque adipiscing commodo elit at imperdiet."
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("p", {
                                                className: "mb-10 text-base font-medium leading-relaxed text-body-color sm:text-lg sm:leading-relaxed lg:text-base lg:leading-relaxed xl:text-lg xl:leading-relaxed",
                                                children: [
                                                    "Semper auctor neque vitae tempus quam pellentesque nec.",
                                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("span", {
                                                        className: "text-primary underline dark:text-white",
                                                        children: [
                                                            " ",
                                                            "Amet dictum sit amet justo",
                                                            " "
                                                        ]
                                                    }),
                                                    "donec enim diam. Varius sit amet mattis vulputate enim nulla aliquet porttitor. Odio pellentesque diam volutpat commodo sed."
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("h3", {
                                                className: "font-xl mb-10 font-bold leading-tight text-black dark:text-white sm:text-2xl sm:leading-tight lg:text-xl lg:leading-tight xl:text-2xl xl:leading-tight",
                                                children: "Digital marketplace for Ui/Ux designers."
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                className: "mb-10 text-base font-medium leading-relaxed text-body-color sm:text-lg sm:leading-relaxed lg:text-base lg:leading-relaxed xl:text-lg xl:leading-relaxed",
                                                children: "consectetur adipiscing elit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat mattis vulputate cupidatat."
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                                className: "mb-10 list-inside list-disc text-body-color",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                        className: "mb-2 text-base font-medium text-body-color sm:text-lg lg:text-base xl:text-lg",
                                                        children: "Consectetur adipiscing elit in voluptate velit."
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                        className: "mb-2 text-base font-medium text-body-color sm:text-lg lg:text-base xl:text-lg",
                                                        children: "Mattis vulputate cupidatat."
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                        className: "mb-2 text-base font-medium text-body-color sm:text-lg lg:text-base xl:text-lg",
                                                        children: "Vulputate enim nulla aliquet porttitor odio pellentesque"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                        className: "mb-2 text-base font-medium text-body-color sm:text-lg lg:text-base xl:text-lg",
                                                        children: "Ligula ullamcorper malesuada proin"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                className: "relative z-10 mb-10 overflow-hidden rounded-md bg-primary bg-opacity-10 p-8 md:p-9 lg:p-8 xl:p-9",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                        className: "text-center text-base font-medium italic text-body-color",
                                                        children: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod incididunt utionals labore et dolore magna aliqua. Quis lobortis scelerisque fermentum, The Neque ut etiam sit amet."
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                        className: "absolute left-0 top-0 z-[-1]",
                                                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("svg", {
                                                            width: "132",
                                                            height: "109",
                                                            viewBox: "0 0 132 109",
                                                            fill: "none",
                                                            xmlns: "http://www.w3.org/2000/svg",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime.jsx("path", {
                                                                    opacity: "0.5",
                                                                    d: "M33.0354 90.11C19.9851 102.723 -3.75916 101.834 -14 99.8125V-15H132C131.456 -12.4396 127.759 -2.95278 117.318 14.5117C104.268 36.3422 78.7114 31.8952 63.2141 41.1934C47.7169 50.4916 49.3482 74.3435 33.0354 90.11Z",
                                                                    fill: "url(#paint0_linear_111:606)"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("path", {
                                                                    opacity: "0.5",
                                                                    d: "M33.3654 85.0768C24.1476 98.7862 1.19876 106.079 -9.12343 108.011L-38.876 22.9988L100.816 -25.8905C100.959 -23.8126 99.8798 -15.5499 94.4164 0.87754C87.5871 21.4119 61.9822 26.677 49.5641 38.7512C37.146 50.8253 44.8877 67.9401 33.3654 85.0768Z",
                                                                    fill: "url(#paint1_linear_111:606)"
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("defs", {
                                                                    children: [
                                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("linearGradient", {
                                                                            id: "paint0_linear_111:606",
                                                                            x1: "94.7523",
                                                                            y1: "82.0246",
                                                                            x2: "8.40951",
                                                                            y2: "52.0609",
                                                                            gradientUnits: "userSpaceOnUse",
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime.jsx("stop", {
                                                                                    stopColor: "white",
                                                                                    stopOpacity: "0.06"
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime.jsx("stop", {
                                                                                    offset: "1",
                                                                                    stopColor: "white",
                                                                                    stopOpacity: "0"
                                                                                })
                                                                            ]
                                                                        }),
                                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("linearGradient", {
                                                                            id: "paint1_linear_111:606",
                                                                            x1: "90.3206",
                                                                            y1: "58.4236",
                                                                            x2: "1.16149",
                                                                            y2: "50.8365",
                                                                            gradientUnits: "userSpaceOnUse",
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime.jsx("stop", {
                                                                                    stopColor: "white",
                                                                                    stopOpacity: "0.06"
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime.jsx("stop", {
                                                                                    offset: "1",
                                                                                    stopColor: "white",
                                                                                    stopOpacity: "0"
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime.jsx("span", {
                                                        className: "absolute right-0 bottom-0 z-[-1]",
                                                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("svg", {
                                                            width: "53",
                                                            height: "30",
                                                            viewBox: "0 0 53 30",
                                                            fill: "none",
                                                            xmlns: "http://www.w3.org/2000/svg",
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime.jsx("circle", {
                                                                    opacity: "0.8",
                                                                    cx: "37.5",
                                                                    cy: "37.5",
                                                                    r: "37.5",
                                                                    fill: "#4A6CF7"
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime.jsx("mask", {
                                                                    id: "mask0_111:596",
                                                                    style: {
                                                                        maskType: "alpha"
                                                                    },
                                                                    maskUnits: "userSpaceOnUse",
                                                                    x: "0",
                                                                    y: "0",
                                                                    width: "75",
                                                                    height: "75",
                                                                    children: /*#__PURE__*/ jsx_runtime.jsx("circle", {
                                                                        opacity: "0.8",
                                                                        cx: "37.5",
                                                                        cy: "37.5",
                                                                        r: "37.5",
                                                                        fill: "#4A6CF7"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("g", {
                                                                    mask: "url(#mask0_111:596)",
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime.jsx("circle", {
                                                                            opacity: "0.8",
                                                                            cx: "37.5",
                                                                            cy: "37.5",
                                                                            r: "37.5",
                                                                            fill: "url(#paint0_radial_111:596)"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime.jsx("g", {
                                                                            opacity: "0.8",
                                                                            filter: "url(#filter0_f_111:596)",
                                                                            children: /*#__PURE__*/ jsx_runtime.jsx("circle", {
                                                                                cx: "40.8089",
                                                                                cy: "19.853",
                                                                                r: "15.4412",
                                                                                fill: "white"
                                                                            })
                                                                        })
                                                                    ]
                                                                }),
                                                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("defs", {
                                                                    children: [
                                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("filter", {
                                                                            id: "filter0_f_111:596",
                                                                            x: "4.36768",
                                                                            y: "-16.5881",
                                                                            width: "72.8823",
                                                                            height: "72.8823",
                                                                            filterUnits: "userSpaceOnUse",
                                                                            colorInterpolationFilters: "sRGB",
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime.jsx("feFlood", {
                                                                                    floodOpacity: "0",
                                                                                    result: "BackgroundImageFix"
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime.jsx("feBlend", {
                                                                                    mode: "normal",
                                                                                    in: "SourceGraphic",
                                                                                    in2: "BackgroundImageFix",
                                                                                    result: "shape"
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime.jsx("feGaussianBlur", {
                                                                                    stdDeviation: "10.5",
                                                                                    result: "effect1_foregroundBlur_111:596"
                                                                                })
                                                                            ]
                                                                        }),
                                                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("radialGradient", {
                                                                            id: "paint0_radial_111:596",
                                                                            cx: "0",
                                                                            cy: "0",
                                                                            r: "1",
                                                                            gradientUnits: "userSpaceOnUse",
                                                                            gradientTransform: "translate(37.5 37.5) rotate(90) scale(40.2574)",
                                                                            children: [
                                                                                /*#__PURE__*/ jsx_runtime.jsx("stop", {
                                                                                    stopOpacity: "0.47"
                                                                                }),
                                                                                /*#__PURE__*/ jsx_runtime.jsx("stop", {
                                                                                    offset: "1",
                                                                                    stopOpacity: "0"
                                                                                })
                                                                            ]
                                                                        })
                                                                    ]
                                                                })
                                                            ]
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("p", {
                                                className: "mb-10 text-base font-medium leading-relaxed text-body-color sm:text-lg sm:leading-relaxed lg:text-base lg:leading-relaxed xl:text-lg xl:leading-relaxed",
                                                children: "consectetur adipiscing elit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat mattis vulputate cupidatat."
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                className: "items-center justify-between sm:flex",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                        className: "mb-5",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime.jsx("h5", {
                                                                className: "mb-3 text-sm font-medium text-body-color",
                                                                children: "Popular Tags :"
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                                className: "flex items-center",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime.jsx(TagButton/* default */.Z, {
                                                                        text: "Design"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime.jsx(TagButton/* default */.Z, {
                                                                        text: "Development"
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime.jsx(TagButton/* default */.Z, {
                                                                        text: "Info"
                                                                    })
                                                                ]
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                                        className: "mb-5",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime.jsx("h5", {
                                                                className: "mb-3 text-sm font-medium text-body-color sm:text-right",
                                                                children: "Share this post :"
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime.jsx("div", {
                                                                className: "flex items-center sm:justify-end",
                                                                children: /*#__PURE__*/ jsx_runtime.jsx(SharePost/* default */.Z, {})
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "w-full px-4 lg:w-4/12",
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx("div", {
                                    className: "mt-12 mb-10 rounded-md bg-primary bg-opacity-5 p-6 dark:bg-opacity-5 lg:mt-0",
                                    children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("form", {
                                        className: "flex items-center justify-between",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime.jsx("input", {
                                                type: "text",
                                                placeholder: "Search here...",
                                                className: "palceholder-body-color mr-5 w-full rounded-md border border-transparent py-3 px-5 text-base font-medium text-body-color outline-none focus:border-primary dark:bg-white dark:bg-opacity-10"
                                            }),
                                            /*#__PURE__*/ jsx_runtime.jsx("button", {
                                                className: "flex h-[50px] w-full max-w-[50px] items-center justify-center rounded-md bg-primary text-white",
                                                children: /*#__PURE__*/ jsx_runtime.jsx("svg", {
                                                    width: "20",
                                                    height: "18",
                                                    viewBox: "0 0 20 18",
                                                    fill: "none",
                                                    xmlns: "http://www.w3.org/2000/svg",
                                                    children: /*#__PURE__*/ jsx_runtime.jsx("path", {
                                                        d: "M19.4062 16.8125L13.9375 12.375C14.9375 11.0625 15.5 9.46875 15.5 7.78125C15.5 5.75 14.7188 3.875 13.2812 2.4375C10.3438 -0.5 5.5625 -0.5 2.59375 2.4375C1.1875 3.84375 0.40625 5.75 0.40625 7.75C0.40625 9.78125 1.1875 11.6562 2.625 13.0937C4.09375 14.5625 6.03125 15.3125 7.96875 15.3125C9.875 15.3125 11.75 14.5938 13.2188 13.1875L18.75 17.6562C18.8438 17.75 18.9688 17.7812 19.0938 17.7812C19.25 17.7812 19.4062 17.7188 19.5312 17.5938C19.6875 17.3438 19.6562 17 19.4062 16.8125ZM3.375 12.3438C2.15625 11.125 1.5 9.5 1.5 7.75C1.5 6 2.15625 4.40625 3.40625 3.1875C4.65625 1.9375 6.3125 1.3125 7.96875 1.3125C9.625 1.3125 11.2812 1.9375 12.5312 3.1875C13.75 4.40625 14.4375 6.03125 14.4375 7.75C14.4375 9.46875 13.7188 11.125 12.5 12.3438C10 14.8438 5.90625 14.8438 3.375 12.3438Z",
                                                        fill: "white"
                                                    })
                                                })
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "mb-10 rounded-md bg-primary bg-opacity-5 dark:bg-opacity-10",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx("h3", {
                                            className: "border-b border-body-color border-opacity-10 py-4 px-8 text-lg font-semibold text-black dark:border-white dark:border-opacity-10 dark:text-white",
                                            children: "Related Posts"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                            className: "p-8",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                    className: "mb-6 border-b border-body-color border-opacity-10 pb-6 dark:border-white dark:border-opacity-10",
                                                    children: /*#__PURE__*/ jsx_runtime.jsx(Blog_RelatedPost, {
                                                        title: "Best way to boost your online sales.",
                                                        image: "/images/blog/post-01.jpg",
                                                        slug: "#",
                                                        date: "12 Feb 2025"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                    className: "mb-6 border-b border-body-color border-opacity-10 pb-6 dark:border-white dark:border-opacity-10",
                                                    children: /*#__PURE__*/ jsx_runtime.jsx(Blog_RelatedPost, {
                                                        title: "50 Best web design tips & tricks that will help you.",
                                                        image: "/images/blog/post-02.jpg",
                                                        slug: "#",
                                                        date: "15 Feb, 2024"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime.jsx(Blog_RelatedPost, {
                                                        title: "The 8 best landing page builders, reviewed",
                                                        image: "/images/blog/post-03.jpg",
                                                        slug: "#",
                                                        date: "05 Jun, 2024"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "mb-10 rounded-md bg-primary bg-opacity-5 dark:bg-opacity-10",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx("h3", {
                                            className: "border-b border-body-color border-opacity-10 py-4 px-8 text-lg font-semibold text-black dark:border-white dark:border-opacity-10 dark:text-white",
                                            children: "Popular Category"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("ul", {
                                            className: "py-6 px-8",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                        href: "#0",
                                                        className: "mb-3 inline-block text-base font-medium text-body-color hover:text-primary",
                                                        children: "Tailwind Templates"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                        href: "#0",
                                                        className: "mb-3 inline-block text-base font-medium text-body-color hover:text-primary",
                                                        children: "Landing page"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                        href: "#0",
                                                        className: "mb-3 inline-block text-base font-medium text-body-color hover:text-primary",
                                                        children: "Startup"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                        href: "#0",
                                                        className: "mb-3 inline-block text-base font-medium text-body-color hover:text-primary",
                                                        children: "Business"
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx("li", {
                                                    children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                                        href: "#0",
                                                        className: "mb-3 inline-block text-base font-medium text-body-color hover:text-primary",
                                                        children: "Multipurpose"
                                                    })
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "mb-10 rounded-md bg-primary bg-opacity-5 dark:bg-opacity-10",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx("h3", {
                                            className: "border-b border-body-color border-opacity-10 py-4 px-8 text-lg font-semibold text-black dark:border-white dark:border-opacity-10 dark:text-white",
                                            children: "Popular Tags"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                            className: "flex flex-wrap py-6 px-8",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime.jsx(TagButton/* default */.Z, {
                                                    text: "Themes"
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx(TagButton/* default */.Z, {
                                                    text: "UI Kit"
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx(TagButton/* default */.Z, {
                                                    text: "Tailwind"
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx(TagButton/* default */.Z, {
                                                    text: "Startup"
                                                }),
                                                /*#__PURE__*/ jsx_runtime.jsx(TagButton/* default */.Z, {
                                                    text: "Business"
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx(NewsLatterBox/* default */.Z, {})
                            ]
                        })
                    ]
                })
            })
        })
    });
};
/* harmony default export */ const page = (BlogSidebarPage);


/***/ }),

/***/ 6259:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";
/* __next_internal_client_entry_do_not_use__ */ 
const { createProxy  } = __webpack_require__(4353);
module.exports = createProxy("C:\\Users\\dell\\Desktop\\next\\node_modules\\next\\dist\\client\\link.js");
 //# sourceMappingURL=link.js.map


/***/ }),

/***/ 2890:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

"use strict";

module.exports = __webpack_require__(6259);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [965,431,551,548,148], () => (__webpack_exec__(8598)));
module.exports = __webpack_exports__;

})();