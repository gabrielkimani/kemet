(() => {
var exports = {};
exports.id = 359;
exports.ids = [359];
exports.modules = {

/***/ 8038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 8704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 7897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 6786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 3280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 2796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 9274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 4014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 8524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 8020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 7342:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/no-ssr-error.js");

/***/ }),

/***/ 4406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 4964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 1751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 6220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 3938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 9565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 5789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 1897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 1428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 8854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 1292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 4567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 979:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/querystring.js");

/***/ }),

/***/ 3297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 6052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 4226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 5052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 3349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 9232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 857:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "metadata": () => (/* binding */ metadata),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_7__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(2315);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2333);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(2885);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9505);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(683);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(3269);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(5746);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8208);
/* harmony import */ var next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_compiled_react_server_dom_webpack_server_browser__WEBPACK_IMPORTED_MODULE_7__);

    const tree = {
        children: [
        '',
        {
        children: [
        'nfts',
        {
        children: ['', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5683)), "C:\\Users\\dell\\Desktop\\next\\app\\nfts\\page.tsx"]}]
      },
        {
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 8514, 23)), "C:\\Users\\dell\\Desktop\\next\\app\\layout.tsx"],
'head': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 447)), "C:\\Users\\dell\\Desktop\\next\\app\\head.tsx"],
        }
      ]
      }.children;
    const metadata = [{
          type: 'layout',
          layer: 0,
          mod: () => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 8514, 23)),
          path: "C:\\Users\\dell\\Desktop\\next\\app\\layout.tsx",
        },{
          type: 'page',
          layer: 1,
          mod: () => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 5683)),
          path: "C:\\Users\\dell\\Desktop\\next\\app\\nfts\\page.tsx",
        },];
    const pages = ["C:\\Users\\dell\\Desktop\\next\\app\\nfts\\page.tsx"];

    
    
    
    

    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
  

/***/ }),

/***/ 3137:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 9446, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 3258, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 6862, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 2030, 23))

/***/ }),

/***/ 5313:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 2919, 23))

/***/ }),

/***/ 5683:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/jsx-runtime.js
var jsx_runtime = __webpack_require__(8499);
// EXTERNAL MODULE: ./node_modules/next/dist/compiled/react/react.shared-subset.js
var react_shared_subset = __webpack_require__(5468);
// EXTERNAL MODULE: ./components/Common/Breadcrumb.tsx
var Breadcrumb = __webpack_require__(151);
;// CONCATENATED MODULE: ./components/Nfts/nftsData.tsx
const nftsData = [
    {
        id: 1,
        title: "UnderWater",
        path: "/nfts",
        newTab: false,
        image: "/images/nfts/1.jpg",
        price: "0.1",
        category: "Art",
        description: "This is a description of the NFT",
        creator: "0x1234567890",
        owner: "0x1234567890",
        contract: "0x1234567890"
    },
    {
        id: 2,
        title: "UnderWater",
        path: "/nfts",
        newTab: false,
        image: "/images/nfts/2.jpg",
        price: "0.1",
        category: "Art",
        description: "This is a description of the NFT",
        creator: "0x1234567890",
        owner: "0x1234567890",
        contract: "0x1234567890"
    },
    {
        id: 3,
        title: "UnderWater",
        path: "/nfts",
        newTab: false,
        image: "/images/nfts/2.jpg",
        price: "0.1",
        category: "Art",
        description: "This is a description of the NFT",
        creator: "0x1234567890",
        owner: "0x1234567890",
        contract: "0x1234567890"
    }
];
/* harmony default export */ const Nfts_nftsData = (nftsData);

// EXTERNAL MODULE: ./components/Blog/TagButton.tsx
var TagButton = __webpack_require__(4110);
;// CONCATENATED MODULE: ./components/Nfts/index.tsx




function Nfts() {
    return /*#__PURE__*/ jsx_runtime.jsx("div", {
        className: "removable mx-3 flex flex-wrap overflow-x-hidden",
        children: Nfts_nftsData.map((nft, index)=>{
            return /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "mb-6 w-full max-w-full px-3 sm:flex-none lg:w-1/3",
                children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                    className: "shadow-soft-xl dark:bg-gray-800 relative flex min-w-0 flex-col break-words rounded-2xl border-0 bg-white bg-opacity-10 bg-clip-border px-3 py-3",
                    children: [
                        /*#__PURE__*/ jsx_runtime.jsx("div", {
                            className: "relative",
                            children: /*#__PURE__*/ jsx_runtime.jsx("a", {
                                className: "block rounded-2xl shadow-xl",
                                children: /*#__PURE__*/ jsx_runtime.jsx("img", {
                                    src: "https://images.unsplash.com/photo-1579833981331-676fa2bae313?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8NHx8YW5pbWF0aW9ufGVufDB8MHwwfHw%3D&auto=format&fit=crop&w=800&q=60",
                                    alt: "img-blur-shadow",
                                    className: "shadow-soft-2xl max-w-full rounded-2xl"
                                })
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "flex-auto px-1 pt-6",
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx(TagButton/* default */.Z, {
                                    text: nft.category
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("p", {
                                    className: "bg-slate-700 dark:text-gray-300 relative z-10 mb-2 bg-clip-text text-sm leading-normal text-transparent",
                                    children: "UnderWater"
                                }),
                                /*#__PURE__*/ jsx_runtime.jsx("a", {
                                    href: "javascript:;",
                                    children: /*#__PURE__*/ jsx_runtime.jsx("h5", {
                                        children: nft.creator
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "mt-4 flex items-center justify-between",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx("button", {
                                            type: "button",
                                            className: "leading-pro ease-soft-in hover:scale-102 active:shadow-soft-xs tracking-tight-soft border-fuchsia-500 text-fuchsia-500 hover:border-fuchsia-500 hover:text-fuchsia-500 active:bg-fuchsia-500 active:hover:text-fuchsia-500 dark:border-gray-700 dark:text-gray-300 dark:hover:text-gray-100 dark:hover:border-gray-100 dark:active:bg-gray-700 dark:active:hover:text-gray-100 mb-0 inline-block cursor-pointer rounded-lg border border-solid bg-transparent px-8 py-2 text-center align-middle text-xs font-bold uppercase shadow-none transition-all hover:bg-transparent hover:opacity-75 hover:shadow-none active:text-white active:hover:bg-transparent dark:hover:bg-transparent dark:hover:opacity-75 dark:active:text-white dark:active:hover:bg-transparent",
                                            children: "Place Bid"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("span", {
                                            children: [
                                                nft.price,
                                                " Points"
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            }, index);
        })
    });
}
/* harmony default export */ const components_Nfts = (Nfts);

;// CONCATENATED MODULE: ./app/nfts/page.tsx





function page_Nfts() {
    return /*#__PURE__*/ (0,jsx_runtime.jsxs)(jsx_runtime.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime.jsx(Breadcrumb/* default */.Z, {
                pageName: "Nfts",
                description: ""
            }),
            /*#__PURE__*/ jsx_runtime.jsx("div", {
                className: "removable mx-3 flex flex-wrap",
                children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                    className: "mb-4 w-full max-w-full px-3 sm:w-full sm:flex-none",
                    children: /*#__PURE__*/ jsx_runtime.jsx("div", {
                        className: "border-black/12.5 shadow-soft-xl dark:bg-gray-800 relative mb-4 flex h-full min-w-0 flex-col break-words rounded-2xl border-0 border-solid bg-transparent bg-clip-border p-4",
                        children: /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                            className: "relative h-full overflow-hidden rounded-xl bg-cover py-6",
                            style: {
                                backgroundImage: "url('https://images.unsplash.com/photo-1655635643532-fa9ba2648cbe?ixlib=rb-1.2.1&amp;ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&amp;auto=format&amp;fit=crop&amp;w=2232&amp;q=80')"
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime.jsx("span", {
                                    className: "from-gray-900 to-slate-800 absolute top-0 left-0 h-full w-full bg-gradient-to-tl bg-cover bg-center opacity-80"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                                    className: "relative z-10 flex h-full flex-auto flex-col p-4",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime.jsx("h2", {
                                            className: "mb-6 pt-2 font-bold text-white",
                                            children: "Discover, create and sell your own NFTs!"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime.jsxs)("a", {
                                            className: "text-size-sm group mt-auto mb-0 font-semibold leading-normal text-white",
                                            href: "javascript:;",
                                            children: [
                                                "Read More",
                                                /*#__PURE__*/ jsx_runtime.jsx("i", {
                                                    className: "fas fa-arrow-right ease-bounce text-size-sm group-hover:translate-x-1.25 ml-1 leading-normal transition-all duration-200",
                                                    "aria-hidden": "true",
                                                    "data-selected": "selected-icon-hover"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                className: "flex space-x-3 justify-around",
                children: [
                    /*#__PURE__*/ jsx_runtime.jsx("h2", {
                        className: "mb-8 ml-8 text-3xl font-bold leading-tight text-black dark:text-white sm:text-4xl sm:leading-tight",
                        children: "NFTs for sale"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime.jsxs)("div", {
                        className: "flex justify-between",
                        children: [
                            /*#__PURE__*/ jsx_runtime.jsx(TagButton/* default */.Z, {
                                text: "All"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx(TagButton/* default */.Z, {
                                text: "Art"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx(TagButton/* default */.Z, {
                                text: "Music"
                            }),
                            /*#__PURE__*/ jsx_runtime.jsx(TagButton/* default */.Z, {
                                text: "Photography"
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime.jsx(components_Nfts, {})
        ]
    });
}
/* harmony default export */ const page = (page_Nfts);


/***/ }),

/***/ 4110:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8499);

const TagButton = ({ href ="#0" , text  })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
        href: href,
        className: "mr-3 mb-3 inline-flex items-center justify-center rounded-md bg-primary bg-opacity-10 py-2 px-4 text-body-color duration-300 hover:bg-opacity-100 hover:text-white",
        children: text
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (TagButton);


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [965,551,151], () => (__webpack_exec__(857)));
module.exports = __webpack_exports__;

})();